<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$host = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'devooti';

$connection = new mysqli($host, $dbUsername, $dbPassword, $dbName);

if ($connection->connect_error) {
    die('Connexion échouée : ' . $connection->connect_error);
}

$cin = $_GET['cin'];

$query = "SELECT * FROM students WHERE cin = '$cin'";
$result = $connection->query($query);

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
    echo json_encode($student);
} else {
    echo json_encode(null);
}

$connection->close();
?>
