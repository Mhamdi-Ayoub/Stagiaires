<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: PUT");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

$method = $_SERVER['REQUEST_METHOD'];

if ($method == "OPTIONS") {
    die();
}

if ($_SERVER['REQUEST_METHOD'] !== 'PUT') {
    http_response_code(405);
    echo json_encode([
        'success' => 0,
        'message' => 'Bad Request detected! Only PUT method is allowed',
    ]);
    exit;
}

require 'db_connect.php';
$database = new Operations();
$conn = $database->dbConnection();

$data = json_decode(file_get_contents("php://input"));

$hobbies = $data->hobbyField;
$hobbies_list = '';
foreach ($hobbies as $hobby) {
    $hobbies_list .= $hobby . ',';
}

if (!isset($data->id)) {
    echo json_encode(['success' => 0, 'message' => 'Please enter correct Students id.']);
    exit;
}

try {
    $fetch_post = "SELECT * FROM `students` WHERE id=:id";
    $fetch_stmt = $conn->prepare($fetch_post);
    $fetch_stmt->bindValue(':id', $data->id, PDO::PARAM_INT);
    $fetch_stmt->execute();

    if ($fetch_stmt->rowCount() > 0) {
        $row = $fetch_stmt->fetch(PDO::FETCH_ASSOC);
        $first_name = isset($data->first_name) ? $data->first_name : $row['first_name'];
        $last_name = isset($data->last_name) ? $data->last_name : $row['last_name'];
        $email = isset($data->email) ? $data->email : $row['email'];
        $password = isset($data->password) ? $data->password : $row['password'];
        $specialiter = isset($data->specialiter) ? $data->specialiter : $row['specialiter'];
        $cin = isset($data->cin) ? $data->cin : $row['cin'];
        $institute = isset($data->institute) ? $data->institute : $row['institute'];

        $diplome_vise = isset($data->diplome_vise) ? $data->diplome_vise : $row['diplome_vise'];
        $nbr_mois = isset($data->nbr_mois) ? $data->nbr_mois : $row['nbr_mois'];
        $date_debut = isset($data->date_debut) ? $data->date_debut : $row['date_debut'];
        $date_fin = isset($data->date_fin) ? $data->date_fin : $row['date_fin'];
        $gender = isset($data->gender) ? $data->gender : $row['gender'];
        $country = isset($data->country) ? $data->country : $row['country'];
        $etat = isset($data->etat) ? $data->etat : $row['etat'];

        $update_query = "UPDATE `students` SET first_name = :first_name, last_name = :last_name, email = :email, password = :password, specialiter = :specialiter, cin = :cin, institute = :institute, diplome_vise = :diplome_vise, nbr_mois = :nbr_mois, date_debut = :date_debut, date_fin = :date_fin, gender = :gender, hobbies = :hobbies, etat = :etat, country = :country WHERE id = :id";

        $update_stmt = $conn->prepare($update_query);

        $update_stmt->bindValue(':first_name', htmlspecialchars(strip_tags($first_name)), PDO::PARAM_STR);
        $update_stmt->bindValue(':last_name', htmlspecialchars(strip_tags($last_name)), PDO::PARAM_STR);
        $update_stmt->bindValue(':email', htmlspecialchars(strip_tags($email)), PDO::PARAM_STR);
        $update_stmt->bindValue(':password', htmlspecialchars(strip_tags($password)), PDO::PARAM_STR);
        $update_stmt->bindValue(':specialiter', htmlspecialchars(strip_tags($specialiter)), PDO::PARAM_STR);
        $update_stmt->bindValue(':cin', htmlspecialchars(strip_tags($cin)), PDO::PARAM_STR);
        $update_stmt->bindValue(':institute', htmlspecialchars(strip_tags($institute)), PDO::PARAM_STR);
        $update_stmt->bindValue(':diplome_vise', htmlspecialchars(strip_tags($diplome_vise)), PDO::PARAM_STR);
        $update_stmt->bindValue(':nbr_mois', htmlspecialchars(strip_tags($nbr_mois)), PDO::PARAM_STR);
        $update_stmt->bindValue(':date_debut', htmlspecialchars(strip_tags($date_debut)), PDO::PARAM_STR);
        $update_stmt->bindValue(':date_fin', htmlspecialchars(strip_tags($date_fin)), PDO::PARAM_STR);
        $update_stmt->bindValue(':gender', htmlspecialchars(strip_tags($gender)), PDO::PARAM_STR);
        $update_stmt->bindValue(':hobbies', htmlspecialchars(strip_tags($hobbies_list)), PDO::PARAM_STR);
        $update_stmt->bindValue(':country', htmlspecialchars(strip_tags($country)), PDO::PARAM_STR);
        $update_stmt->bindValue(':id', $data->id, PDO::PARAM_INT);
        $update_stmt->bindValue(':etat', htmlspecialchars(strip_tags($etat)), PDO::PARAM_STR);

        if ($update_stmt->execute()) {
            echo json_encode([
                'success' => 1,
                'message' => 'Record updated successfully'
            ]);
            exit;
        }

        echo json_encode([
            'success' => 0,
            'message' => 'Did not update. Something went wrong.'
        ]);
        exit;

    } else {
        echo json_encode(['success' => 0, 'message' => 'Invalid ID. No record found by the ID.']);
        exit;
    }
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => 0,
        'message' => $e->getMessage()
    ]);
    exit;
}
?>
