<?php
header("Access-Control-Allow-Origin: *");  // Ou spécifiez le domaine approprié au lieu de "*"
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

$targetDir = 'uploads/';
$targetFile = $targetDir . basename($_FILES['pdf']['name']);
$uploadOk = 1;
$fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

// Check if the file is a PDF
if ($fileType != 'pdf') {
    echo json_encode(['message' => 'Only PDF files are allowed.']);
    $uploadOk = 0;
}

// Check if file already exists
if (file_exists($targetFile)) {
    echo json_encode(['message' => 'File already exists.']);
    $uploadOk = 0;
}

// Upload the file
if ($uploadOk == 0) {
    echo json_encode(['message' => 'File was not uploaded.']);
} else {
    if (move_uploaded_file($_FILES['pdf']['tmp_name'], $targetFile)) {
        echo json_encode(['message' => 'File uploaded successfully.']);
    } else {
        echo json_encode(['message' => 'An error occurred during upload.']);
    }
}
?>
