<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

$host = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'devooti';

$connection = new mysqli($host, $dbUsername, $dbPassword, $dbName);

if ($connection->connect_error) {
    die('Connexion échouée : ' . $connection->connect_error);
}

$data = json_decode(file_get_contents("php://input"), true);

$cin = $data['cin'];

$query = "UPDATE students SET archived = 1 WHERE cin = '$cin'";

if ($connection->query($query) === TRUE) {
    echo json_encode(array("message" => "Étudiant archivé avec succès."));
} else {
    echo json_encode(array("message" => "Erreur lors de l'archivage de l'étudiant : " . $connection->error));
}

$connection->close();
?>
