<?php
include_once("database.php");
$postdata = file_get_contents("php://input");
if(isset($postdata) && !empty($postdata))
{
$request = json_decode($postdata);
$name = trim($request->name);
$pwd = mysqli_real_escape_string($mysqli, trim($request->pwd));
$email = mysqli_real_escape_string($mysqli, trim($request->email));
$specialite = mysqli_real_escape_string($mysqli, trim($request->specialite)); 
$cin = mysqli_real_escape_string($mysqli, trim($request->cin)); 
$institute = mysqli_real_escape_string($mysqli, trim($request->institute));
$diploma = mysqli_real_escape_string($mysqli, trim($request->diploma));
$dateDebut = mysqli_real_escape_string($mysqli, trim($request->dateDebut));
$dateFin = mysqli_real_escape_string($mysqli, trim($request->dateFin));
$nbrMois = mysqli_real_escape_string($mysqli, trim($request->nbrMois));
$sql = "INSERT INTO users(name, password, email, specialite, cin, institute, diploma, dateDebut, dateFin, nbrMois) VALUES ('$name', '$pwd', '$email', '$specialite', '$cin', '$institute', '$diploma', '$dateDebut', '$dateFin','$nbrMois')";

if ($mysqli->query($sql) === TRUE) {
$authdata = [
'name' => $name,
'pwd' => '',
'email' => $email,
'Id' => mysqli_insert_id($mysqli),
'specialite' => $specialite,
'cin' =>$cin,
'institute' =>$institute,
'diploma' =>$diploma,
'dateDebut' =>$dateDebut,
'dateFin' =>$dateFin,
'nbrMois' =>$nbrMois
];
echo json_encode($authdata);
}
}

?>