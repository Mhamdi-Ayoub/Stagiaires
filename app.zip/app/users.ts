export class Users {
    public Id: number;
    public name: string;
    public pwd: string;
    public email: string;
    public specialite: string;
    public cin: string; 
    public institute: string;
    public diploma: string;
    public dateDebut: string;
    public dateFin: string;
    public nbrMois: string;
  
    constructor(Id: number, name: string, pwd: string, email: string, specialite: string, cin: string, institute: string, diploma: string, dateDebut: string, dateFin: string, nbrMois: string) {
      this.Id = Id;
      this.name = name;
      this.pwd = pwd;
      this.email = email;
      this.specialite = specialite; 
      this.cin = cin;
      this.institute = institute;
      this.diploma = diploma ;
      this.dateDebut = dateDebut;
      this.dateFin = dateFin;
      this.nbrMois = nbrMois;
    }
  }
  