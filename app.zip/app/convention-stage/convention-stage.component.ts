import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-convention-stage',
  templateUrl: './convention-stage.component.html',
  styleUrls: ['./convention-stage.component.css']
})
export class ConventionStageComponent {
  selectedFile: File | null = null;
  uploadResponse: string | null = null;

  constructor(
    private http: HttpClient,
    private router: Router // Injectez le service Router dans le constructeur
  ) {}

  handleFileInput(event: any) {
    this.selectedFile = event.target.files[0];
  }

  uploadFile() {
    if (this.selectedFile) {
      const formData = new FormData();
      formData.append('pdf', this.selectedFile);

      this.http.post<any>('http://localhost/angular_admin/php/upload.php', formData).subscribe(
        (response) => {
          this.uploadResponse = response.message;
          
          // Redirigez vers la page "home-stagiaire" après le téléchargement réussi
          this.router.navigate(['home_stagiaire']);
        },
        (error) => {
          this.uploadResponse = 'An error occurred during upload.';
        }
      );
    }
  }
}
