import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InterfaceStagiaireComponent } from './interface-stagiaire.component';

describe('InterfaceStagiaireComponent', () => {
  let component: InterfaceStagiaireComponent;
  let fixture: ComponentFixture<InterfaceStagiaireComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InterfaceStagiaireComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InterfaceStagiaireComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
