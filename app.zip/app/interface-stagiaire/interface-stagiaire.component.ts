import { OnInit, Component } from '@angular/core';
import { StudentsService } from '../students.service';

@Component({
  selector: 'app-interface-stagiaire',
  templateUrl: './interface-stagiaire.component.html',
  styleUrls: ['./interface-stagiaire.component.css']
})
export class InterfaceStagiaireComponent implements OnInit {
  students: any[] = []; // Initialize the students array property

  constructor(private studentsservice: StudentsService) { }

  ngOnInit(): void {
    this.studentsservice.getStudents().subscribe(
      (result: any) => {
        this.students = result.data;
      }
    );
  }

  deleteStudent(student: any) {
    this.studentsservice.deleteStudent(student.id).subscribe(data => {
      this.students = this.students.filter((u: any) => u !== student);
    });
  }
}
