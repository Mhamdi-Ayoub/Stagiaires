import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-archive',
  templateUrl: './archive.component.html',
  styleUrls: ['./archive.component.css']
})
export class ArchiveComponent {
  cin: string = '';
  successMessage: string = '';
  errorMessage: string = '';

  constructor(private http: HttpClient) { }

  archiveStudent() {
    this.successMessage = '';
    this.errorMessage = '';

    this.http.post<any>('http://localhost/angular_admin/php/archive.php', { cin: this.cin })
      .subscribe(
        data => {
          if (data && data.message) {
            this.successMessage = data.message;
          } else {
            this.errorMessage = 'Une erreur est survenue lors de l\'archivage de l\'étudiant.';
          }
        },
        error => {
          console.error(error);
          this.errorMessage = 'Une erreur est survenue lors de l\'archivage de l\'étudiant.';
        }
      );
  }
}
