import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
})
export class UploadComponent {
  selectedFile: File | null = null;
  uploadResponse: string | null = null;

  constructor(private http: HttpClient) {}

  handleFileInput(event: any) {
    this.selectedFile = event.target.files[0];
  }

  uploadFile() {
    if (this.selectedFile) {
      const formData = new FormData();
      formData.append('pdf', this.selectedFile);

      this.http.post<any>('http://localhost/angular_admin/php/upload.php', formData).subscribe(
        (response) => {
          this.uploadResponse = response.message;
        },
        (error) => {
          this.uploadResponse = 'An error occurred during upload.';
        }
      );
    }
  }
}
