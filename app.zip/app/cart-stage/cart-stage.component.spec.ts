import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CartStageComponent } from './cart-stage.component';

describe('CartStageComponent', () => {
  let component: CartStageComponent;
  let fixture: ComponentFixture<CartStageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CartStageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CartStageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
