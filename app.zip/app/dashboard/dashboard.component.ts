import { Component } from '@angular/core';
@Component({
  selector: 'dashboard-root',
  templateUrl: './dashboard.component.html'
})
export class dashboardComponent {
  title = 'crud';
}
