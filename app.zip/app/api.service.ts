import { Injectable, Output, EventEmitter } from '@angular/core';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { Users } from './users';



@Injectable({
  providedIn: 'root'
})
export class ApiService {
  redirectUrl: string = ''; // Initialize redirectUrl
  baseUrl: string = "http://localhost/angular_admin/php";
  @Output() getLoggedInName: EventEmitter<any> = new EventEmitter();

  constructor(private httpClient: HttpClient) { }


  public userlogin(username: string, password: string) { // Add explicit types to parameters
    alert(username);
    return this.httpClient.post<any>(this.baseUrl + '/login.php', { username, password })
      .pipe(map((users: Users[]) => { // Update variable name to 'users'
        this.setToken(users[0].name);
        this.getLoggedInName.emit(true);
        return users;
      }));
  }

  public userregistration(name: string, email: string, pwd: string,specialite: string,cin: string, institute: string, diploma: string, dateDebut: string, dateFin: string, nbrMois: string) { // Add explicit types to parameters
    return this.httpClient.post<any>(this.baseUrl + '/register.php', { name, email, pwd, specialite, cin, institute, diploma, dateDebut, dateFin, nbrMois })
      .pipe(map((users: Users[]) => { // Update variable name to 'users'
        return users;
      }));
  }

  //token
  setToken(token: string) {
    localStorage.setItem('token', token);
  }

  getToken() {
    return localStorage.getItem('token');
  }

  deleteToken() {
    localStorage.removeItem('token');
  }

  isLoggedIn() {
    const userToken = this.getToken();
    if (userToken !== null) { // Use strict equality !==
      return true;
    }
    return false;
  }
}
