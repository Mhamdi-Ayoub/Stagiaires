import { CommonModule } from '@angular/common';
import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { RegisterComponent } from './register/register.component';
import { dashboardComponent } from './dashboard/dashboard.component';
import { AuthguardGuard } from './authguard.guard';
import { UploadComponent } from './upload/upload.component';
import { AddStudentsComponent } from './add-students/add-students.component';
import { EditStudentsComponent } from './edit-students/edit-students.component';
import { ListStudentsComponent } from './list-students/list-students.component';
import { AddComponent } from './add/add.component';
import { SlideComponent } from './slide/slide.component';
import { InterfaceStagiaireComponent } from './interface-stagiaire/interface-stagiaire.component';
import { SearchComponent } from './search/search.component';
import { ArchiveComponent } from './archive/archive.component';
import { HomeStagiaireComponent } from './home-stagiaire/home-stagiaire.component';
import { TitleStagComponent } from './title-stag/title-stag.component';
import { CartStageComponent } from './cart-stage/cart-stage.component';
import { SearchStagiareComponent } from './search-stagiare/search-stagiare.component';
import { DemanderComponent } from './demander/demander.component';
import { ConventionStageComponent } from './convention-stage/convention-stage.component';







const routes: Routes = [

{ path: '', component: LoginComponent },
{ path: 'home', component: HomeComponent },
{ path: 'registration', component: RegisterComponent },
{ path: 'dashboard', component: dashboardComponent,canActivate: [AuthguardGuard] },
{ path: 'upload', component: UploadComponent},
{ path: 'list-student', component: ListStudentsComponent, pathMatch: 'full' },
{ path: 'add-student', component: AddStudentsComponent },
{path: 'edit/:id', component: EditStudentsComponent },
{ path: 'add' , component: AddComponent},
{ path: 'slide', component: SlideComponent},
{path :'interface-stagiaire',component:InterfaceStagiaireComponent},
{path: 'search',component:SearchComponent},
{path:'archive',component:ArchiveComponent},
{path:'home_stagiaire',component:HomeStagiaireComponent},
{path:'carte-stage',component:CartStageComponent},
{path:'title-stage',component:CartStageComponent},
{path:'search-stagiare',component:SearchStagiareComponent},
{path:'demander',component:DemanderComponent},
{path:'convention',component:ConventionStageComponent}







]

@NgModule({
imports: [CommonModule,RouterModule.forRoot(routes)],
exports: [RouterModule]
})

export class AppRoutingModule { }