import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-search-stagiare',
  templateUrl: './search-stagiare.component.html',
  styleUrls: ['./search-stagiare.component.css']
})
export class SearchStagiareComponent {
  cin: string = '';
  student: any = null;
  errorMessage: string = '';

  constructor(private http: HttpClient) { }

  search() {
    this.errorMessage = '';
    this.student = null;
    
    this.http.get<any>(`http://localhost/angular_admin/php/search.php?cin=${this.cin}`)
      .subscribe(
        data => {
          if (data) {
            this.student = data;
          } else {
            this.errorMessage = 'Aucun étudiant trouvé avec ce CIN.';
          }
        },
        error => {
          console.error(error);
          this.errorMessage = 'Une erreur est survenue lors de la recherche.';
        }
      );
  }
}
