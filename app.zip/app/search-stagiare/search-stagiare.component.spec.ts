import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchStagiareComponent } from './search-stagiare.component';

describe('SearchStagiareComponent', () => {
  let component: SearchStagiareComponent;
  let fixture: ComponentFixture<SearchStagiareComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SearchStagiareComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SearchStagiareComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
