import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { dashboardComponent } from './dashboard/dashboard.component';
import { CartesComponent } from './cartes/cartes.component';
import { TitleComponent } from './title/title.component';
import { FooterComponent } from './footer/footer.component';
import { UploadComponent } from './upload/upload.component';
import { AddStudentsComponent } from './add-students/add-students.component';
import { EditStudentsComponent } from './edit-students/edit-students.component';
import { ListStudentsComponent } from './list-students/list-students.component';
import { AddComponent } from './add/add.component';
import { SlideComponent } from './slide/slide.component';
import { InterfaceStagiaireComponent } from './interface-stagiaire/interface-stagiaire.component';
import { SearchComponent } from './search/search.component';
import { ArchiveComponent } from './archive/archive.component';
import { HomeStagiaireComponent } from './home-stagiaire/home-stagiaire.component';
import { TitleStagComponent } from './title-stag/title-stag.component';
import { CartStageComponent } from './cart-stage/cart-stage.component';
import { SearchStagiareComponent } from './search-stagiare/search-stagiare.component';
import { DemanderComponent } from './demander/demander.component';
import { ConventionStageComponent } from './convention-stage/convention-stage.component';








@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    dashboardComponent,
    CartesComponent,
    TitleComponent,
    FooterComponent,
    UploadComponent,
    AddStudentsComponent,
    EditStudentsComponent,
    ListStudentsComponent,
    AddComponent,
    SlideComponent,
    InterfaceStagiaireComponent,
    SearchComponent,
    ArchiveComponent,
    HomeStagiaireComponent,
    TitleStagComponent,
    CartStageComponent,
    SearchStagiareComponent,
    DemanderComponent,
    ConventionStageComponent,

   
  
    

   
  
  ],
  imports: [
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
  ],
  providers: [],
  bootstrap: [AppComponent ],
})
export class AppModule {}
