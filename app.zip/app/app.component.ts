import { Component, OnInit } from '@angular/core';
import { ApiService } from './api.service';
import { HttpClient } from '@angular/common/http';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent  { 
  //users: User[] = [];
  loginbtn: boolean;
  logoutbtn: boolean;
  title = 'angular_admin';

  constructor(private http: HttpClient, private dataService: ApiService) {
    dataService.getLoggedInName.subscribe(name => this.changeName(name));
    if(this.dataService.isLoggedIn()) {
      console.log("loggedin");
      this.loginbtn =false;
      this.logoutbtn = true;
      
    } else {
      this.loginbtn = true;
      this.logoutbtn = false;
    }
  }

  //ngOnInit() {
   // this.getUsers();
// }

  //getUsers() {
    //this.http.get<User[]>('http://localhost/angular_admin/php/get.php').subscribe(data => {
    //  this.users = data;
   // });
  //}

  //addUser(name: string, email: string) {
   // const user = { name, email };
   // this.http.post('http://localhost/angular_admin/php/insert.php', user).subscribe(() => {
    //  this.getUsers();
    //});
  //}

  //updateUser(id: number, name: string, email: string) {
    //const user = { id, name, email };
   // this.http.put(`http://localhost/angular_admin/php/update.php`, user).subscribe(() => {
    //  this.getUsers();
    //});
 // }

  //deleteUser(id: number) {
  //  const user = { id };
   // this.http.post(`http://localhost/angular_admin/php/delete.php`, user).subscribe(() => {
     // this.getUsers();
    //});
  //}

  logout() {
    this.dataService.deleteToken();
    window.location.href = window.location.href;
   
    
  }

  private changeName(name: boolean): void {
    this.logoutbtn = name;
    this.loginbtn = !name;
    
  }
}
