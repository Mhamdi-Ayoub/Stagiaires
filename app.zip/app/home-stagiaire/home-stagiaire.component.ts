import { Component } from '@angular/core';

@Component({
  selector: 'app-home-stagiaire',
  templateUrl: './home-stagiaire.component.html',
  styleUrls: ['./home-stagiaire.component.css']
})
export class HomeStagiaireComponent {

}
