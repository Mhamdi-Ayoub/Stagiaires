import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TitleStagComponent } from './title-stag.component';

describe('TitleStagComponent', () => {
  let component: TitleStagComponent;
  let fixture: ComponentFixture<TitleStagComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TitleStagComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TitleStagComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
