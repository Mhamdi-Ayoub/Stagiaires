import { Component } from '@angular/core';

@Component({
  selector: 'app-title-stag',
  templateUrl: './title-stag.component.html',
  styleUrls: ['./title-stag.component.css']
})
export class TitleStagComponent {

}
