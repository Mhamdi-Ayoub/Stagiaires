import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'; // Importez le Router depuis Angular Router
import { StudentsService } from '../students.service';

@Component({
  selector: 'app-list-students',
  templateUrl: './list-students.component.html',
  styleUrls: ['./list-students.component.css']
})
export class ListStudentsComponent implements OnInit {
  students: any;

  constructor(private studentsservice: StudentsService, private router: Router) { }

  ngOnInit(): void {
    this.studentsservice.getStudents().subscribe(
      (result: any) => {
        this.students = result.data;
      }
    )
  }

  deleteStudent(student: any) {
    this.studentsservice.deleteStudent(student.id).subscribe(data => {
      this.students = this.students.filter((u: any) => u !== student);
    })
  }

  redire() {
    this.router.navigate(['home']); // Utilisez le Router pour rediriger vers la page d'accueil
  }
}
