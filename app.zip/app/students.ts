export class Students{
    id?: number;  
    first_name?: string;  
    last_name?: string;  
    email?: string;  
    passwod?: string; 
    gender?: string;
    hobbies?: string;
    country?: string;
    specialiter?: string;
    cin?: string;
    institute?: string;
    diplome_vise?: string;
    nbr_mois?: string;
    date_debut?: string;
    date_fin?: string;
    etat?: string;
}