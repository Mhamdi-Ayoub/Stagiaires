import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DemanderComponent } from './demander.component';

describe('DemanderComponent', () => {
  let component: DemanderComponent;
  let fixture: ComponentFixture<DemanderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DemanderComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DemanderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
