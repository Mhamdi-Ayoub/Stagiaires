import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-demander',
  templateUrl: './demander.component.html',
  styleUrls: ['./demander.component.css']
})
export class DemanderComponent implements OnInit{

  angForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private dataService: ApiService,
    private router: Router
  ) {
    this.angForm = this.fb.group({
      email: ['', [Validators.required, Validators.minLength(1), Validators.email]],
      password: ['', Validators.required],
      name: ['', Validators.required],
      mobile: ['', Validators.required],
      specialite: ['', Validators.required],
      cin: ['', Validators.required],
      institute: ['', Validators.required],
      diploma: ['', Validators.required],
      dateDebut: ['', Validators.required],
      dateFin: ['', Validators.required],
      nbrMois: ['', Validators.required]
    });
  }

  ngOnInit() {}

  postdata() {
    this.dataService.userregistration(
      this.angForm.value.email,
      this.angForm.value.name,
      this.angForm.value.password,
      this.angForm.value.specialite,
      this.angForm.value.cin,
      this.angForm.value.institute,
      this.angForm.value.diploma,
      this.angForm.value.dateDebut,
      this.angForm.value.dateFin,
      this.angForm.value.nbrMois
    )
      .pipe(first())
      .subscribe(
        (data) => {
          this.router.navigate(['home_stagiaire']);
        },
        (error) => {}
      );
  }

  get email() {
    return this.angForm.get('email');
  }
  get password() {
    return this.angForm.get('password');
  }
  get name() {
    return this.angForm.get('name');
  }
  get specialite() {
    return this.angForm.get('specialite');
  }
  get cin() {
    return this.angForm.get('cin');
  }
  get institute() {
    return this.angForm.get('institute');
  }
  get diploma() {
    return this.angForm.get('diploma');
  }
  get dateDebut() {
    return this.angForm.get('dateDebut');
  }
  get dateFin() {
    return this.angForm.get('dateFin');
  }
  get nbrMois() {
    return this.angForm.get('nbrMois');
  }

}

